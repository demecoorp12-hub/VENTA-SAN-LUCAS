
# Sistema San Lucas

## Ejecutar Frontend
Abrir frontend/index.html

## Ejecutar Backend
cd backend
npm install
node server.js

## Base de Datos
Importar database/san_lucas.sql en MySQL
