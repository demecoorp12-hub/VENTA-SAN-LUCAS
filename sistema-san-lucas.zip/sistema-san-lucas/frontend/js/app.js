
console.log("Sistema San Lucas iniciado correctamente");
