
CREATE DATABASE san_lucas;
USE san_lucas;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50),
    password VARCHAR(100),
    rol VARCHAR(30)
);

CREATE TABLE pasajeros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombres VARCHAR(100),
    apellidos VARCHAR(100),
    ci VARCHAR(30),
    telefono VARCHAR(30)
);

CREATE TABLE rutas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    origen VARCHAR(100),
    destino VARCHAR(100),
    precio DECIMAL(10,2)
);

CREATE TABLE boletos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pasajero_id INT,
    ruta_id INT,
    asiento INT,
    fecha_viaje DATE
);
